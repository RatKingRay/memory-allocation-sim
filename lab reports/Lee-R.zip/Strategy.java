/* public interface Strategy {
    public String execute();
}

class FF implements Strategy {
    public String execute(){
        int memorySpace =  
        return null;
    }
}

class BF implements Strategy {
    public String execute(){

        return null;
    }
}

class WF implements Strategy {
    public String execute(){

        return null;
    }
}    */